/* ============================================================
   InspireU Disability Support — Main JavaScript
   ============================================================ */

(function () {
  'use strict';

  /* ── NAV SCROLL BEHAVIOUR ── */
  const header = document.querySelector('.site-header');
  const isHeroPage = header && header.classList.contains('hero-mode-init');

  function updateNav() {
    if (!header) return;
    const scrolled = window.scrollY > 60;
    if (isHeroPage) {
      if (scrolled) {
        header.classList.remove('hero-mode');
        header.classList.add('scrolled', 'solid');
      } else {
        header.classList.add('hero-mode');
        header.classList.remove('scrolled', 'solid');
      }
    }
  }

  if (header) {
    window.addEventListener('scroll', updateNav, { passive: true });
    updateNav();
  }

  /* ── MOBILE NAV TOGGLE ── */
  const navToggle = document.querySelector('.nav-toggle');
  const navLinks  = document.querySelector('.nav-links');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      const isOpen = navLinks.classList.toggle('open');
      navToggle.classList.toggle('open', isOpen);
      navToggle.setAttribute('aria-expanded', isOpen);
      navToggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
    });

    // Close menu on link click
    navLinks.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navLinks.classList.remove('open');
        navToggle.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });

    // Close menu on outside click
    document.addEventListener('click', function (e) {
      if (!header.contains(e.target) && navLinks.classList.contains('open')) {
        navLinks.classList.remove('open');
        navToggle.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ── ACTIVE NAV LINK ── */
  (function setActiveLink() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('.nav-links a').forEach(function (link) {
      const href = link.getAttribute('href');
      if (href === currentPage || (currentPage === '' && href === 'index.html')) {
        link.classList.add('active');
        link.setAttribute('aria-current', 'page');
      }
    });
  })();

  /* ── SCROLL REVEAL ── */
  const revealElements = document.querySelectorAll('[data-reveal]');
  if (revealElements.length && 'IntersectionObserver' in window) {
    const revealObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          const el = entry.target;
          const delay = el.dataset.revealDelay || '0';
          el.style.animationDelay = delay + 'ms';
          el.classList.add('revealed');
          revealObserver.unobserve(el);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

    revealElements.forEach(function (el) {
      el.classList.add('will-reveal');
      revealObserver.observe(el);
    });
  }

  /* ── FILE UPLOAD LABEL UPDATE ── */
  const fileInputs = document.querySelectorAll('input[type="file"]');
  fileInputs.forEach(function (input) {
    input.addEventListener('change', function () {
      const label = document.querySelector('label[for="' + input.id + '"] p');
      if (label && input.files.length > 0) {
        label.innerHTML = '<strong>✓ ' + input.files[0].name + '</strong>';
      }
    });
  });

  /* ── ENQUIRY FORM HANDLING ── */
  const enquiryForm = document.getElementById('enquiry-form');
  if (enquiryForm) {
    enquiryForm.addEventListener('submit', function (e) {
      e.preventDefault();
      const btn = enquiryForm.querySelector('.btn-submit');
      const originalText = btn.textContent;
      btn.textContent = 'Sending…';
      btn.disabled = true;

      // Simulate send (replace with real backend / Formspree / Netlify etc.)
      setTimeout(function () {
        const successMsg = document.getElementById('form-success');
        if (successMsg) {
          enquiryForm.style.display = 'none';
          successMsg.hidden = false;
          successMsg.focus();
        } else {
          btn.textContent = '✓ Sent! We\'ll be in touch soon.';
          btn.style.background = 'linear-gradient(135deg, #059669, #10B981)';
        }
      }, 1200);
    });
  }

  /* ── SMOOTH SCROLL FOR ANCHOR LINKS ── */
  document.querySelectorAll('a[href^="#"]').forEach(function (anchor) {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        const headerHeight = header ? header.offsetHeight : 0;
        const top = target.getBoundingClientRect().top + window.scrollY - headerHeight - 16;
        window.scrollTo({ top: top, behavior: 'smooth' });
      }
    });
  });

})();
